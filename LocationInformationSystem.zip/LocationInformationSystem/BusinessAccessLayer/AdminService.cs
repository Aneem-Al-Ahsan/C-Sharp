﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using EntityLayer;

namespace BusinessAccessLayer
{
    public class AdminService
    {
        AdminDataAccess adminDataAccess = new AdminDataAccess();
        public int Add(Admin admin)
        {
            return adminDataAccess.Add(admin);
        }
        public int Delete(Admin admin)
        {
            return adminDataAccess.Delete(admin);
        }
        public List<Admin> GetAll()
        {
            return adminDataAccess.GetAll();
        }
        public int EditName(Admin admin)
        {
            return adminDataAccess.EditName(admin);
        }
        public int EditPassword(Admin admin)
        {
            return adminDataAccess.EditPassword(admin);
        }

    }
}
