﻿namespace PresentationLayer
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Adminbtn = new System.Windows.Forms.Button();
            this.Userbtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Loginexitbtn = new System.Windows.Forms.Button();
            this.Loginbackbtn = new System.Windows.Forms.Button();
            this.Passtxt = new System.Windows.Forms.TextBox();
            this.Passlbl = new System.Windows.Forms.Label();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.Loginlbl = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.logOutBtn = new System.Windows.Forms.Button();
            this.searchAllBtn = new System.Windows.Forms.Button();
            this.searchTypeBtn = new System.Windows.Forms.Button();
            this.Searchbtn = new System.Windows.Forms.Button();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.Editbtn = new System.Windows.Forms.Button();
            this.Addbtn = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Adminbtn);
            this.panel1.Controls.Add(this.Userbtn);
            this.panel1.Location = new System.Drawing.Point(280, 96);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(211, 144);
            this.panel1.TabIndex = 0;
            // 
            // Adminbtn
            // 
            this.Adminbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Adminbtn.Location = new System.Drawing.Point(3, 74);
            this.Adminbtn.Name = "Adminbtn";
            this.Adminbtn.Size = new System.Drawing.Size(205, 71);
            this.Adminbtn.TabIndex = 1;
            this.Adminbtn.Text = "Admin";
            this.toolTip1.SetToolTip(this.Adminbtn, "Takes to admin \r\noperations");
            this.Adminbtn.UseVisualStyleBackColor = false;
            this.Adminbtn.Click += new System.EventHandler(this.Adminbtn_Click);
            // 
            // Userbtn
            // 
            this.Userbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Userbtn.Location = new System.Drawing.Point(3, 0);
            this.Userbtn.Name = "Userbtn";
            this.Userbtn.Size = new System.Drawing.Size(205, 74);
            this.Userbtn.TabIndex = 0;
            this.Userbtn.Text = "User";
            this.toolTip1.SetToolTip(this.Userbtn, "Takes to\r\nsearching option");
            this.Userbtn.UseVisualStyleBackColor = false;
            this.Userbtn.Click += new System.EventHandler(this.Userbtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Loginexitbtn);
            this.panel2.Controls.Add(this.Loginbackbtn);
            this.panel2.Controls.Add(this.Passtxt);
            this.panel2.Controls.Add(this.Passlbl);
            this.panel2.Controls.Add(this.Nametxt);
            this.panel2.Controls.Add(this.Loginlbl);
            this.panel2.Location = new System.Drawing.Point(525, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(252, 145);
            this.panel2.TabIndex = 1;
            // 
            // Loginexitbtn
            // 
            this.Loginexitbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Loginexitbtn.Location = new System.Drawing.Point(183, 120);
            this.Loginexitbtn.Name = "Loginexitbtn";
            this.Loginexitbtn.Size = new System.Drawing.Size(66, 22);
            this.Loginexitbtn.TabIndex = 8;
            this.Loginexitbtn.Text = "Exit";
            this.Loginexitbtn.UseVisualStyleBackColor = false;
            this.Loginexitbtn.Click += new System.EventHandler(this.Loginexitbtn_Click);
            // 
            // Loginbackbtn
            // 
            this.Loginbackbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Loginbackbtn.Location = new System.Drawing.Point(3, 120);
            this.Loginbackbtn.Name = "Loginbackbtn";
            this.Loginbackbtn.Size = new System.Drawing.Size(66, 22);
            this.Loginbackbtn.TabIndex = 5;
            this.Loginbackbtn.Text = "Ok";
            this.Loginbackbtn.UseVisualStyleBackColor = false;
            this.Loginbackbtn.Click += new System.EventHandler(this.Loginbackbtn_Click);
            // 
            // Passtxt
            // 
            this.Passtxt.BackColor = System.Drawing.Color.White;
            this.Passtxt.Location = new System.Drawing.Point(73, 53);
            this.Passtxt.Name = "Passtxt";
            this.Passtxt.Size = new System.Drawing.Size(164, 20);
            this.Passtxt.TabIndex = 7;
            this.toolTip1.SetToolTip(this.Passtxt, "enter admin password");
            // 
            // Passlbl
            // 
            this.Passlbl.AutoSize = true;
            this.Passlbl.Location = new System.Drawing.Point(3, 53);
            this.Passlbl.Name = "Passlbl";
            this.Passlbl.Size = new System.Drawing.Size(53, 13);
            this.Passlbl.TabIndex = 6;
            this.Passlbl.Text = "Password";
            // 
            // Nametxt
            // 
            this.Nametxt.BackColor = System.Drawing.Color.White;
            this.Nametxt.Location = new System.Drawing.Point(73, 3);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(164, 20);
            this.Nametxt.TabIndex = 5;
            this.toolTip1.SetToolTip(this.Nametxt, "Enter admin \r\nlogin name");
            // 
            // Loginlbl
            // 
            this.Loginlbl.AutoSize = true;
            this.Loginlbl.Location = new System.Drawing.Point(3, 3);
            this.Loginlbl.Name = "Loginlbl";
            this.Loginlbl.Size = new System.Drawing.Size(35, 13);
            this.Loginlbl.TabIndex = 4;
            this.Loginlbl.Text = "Name";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.logOutBtn);
            this.panel3.Controls.Add(this.searchAllBtn);
            this.panel3.Controls.Add(this.searchTypeBtn);
            this.panel3.Controls.Add(this.Searchbtn);
            this.panel3.Controls.Add(this.Deletebtn);
            this.panel3.Controls.Add(this.Editbtn);
            this.panel3.Controls.Add(this.Addbtn);
            this.panel3.Location = new System.Drawing.Point(12, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(179, 317);
            this.panel3.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button1.Location = new System.Drawing.Point(3, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(173, 33);
            this.button1.TabIndex = 7;
            this.button1.Text = "Back";
            this.toolTip1.SetToolTip(this.button1, "Lets admin logout");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // logOutBtn
            // 
            this.logOutBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.logOutBtn.Location = new System.Drawing.Point(3, 216);
            this.logOutBtn.Name = "logOutBtn";
            this.logOutBtn.Size = new System.Drawing.Size(173, 33);
            this.logOutBtn.TabIndex = 6;
            this.logOutBtn.Text = "Logout";
            this.toolTip1.SetToolTip(this.logOutBtn, "Lets admin logout");
            this.logOutBtn.UseVisualStyleBackColor = false;
            this.logOutBtn.Click += new System.EventHandler(this.logOutBtn_Click);
            // 
            // searchAllBtn
            // 
            this.searchAllBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.searchAllBtn.Location = new System.Drawing.Point(3, 138);
            this.searchAllBtn.Name = "searchAllBtn";
            this.searchAllBtn.Size = new System.Drawing.Size(173, 33);
            this.searchAllBtn.TabIndex = 5;
            this.searchAllBtn.Text = "Search All";
            this.toolTip1.SetToolTip(this.searchAllBtn, "Searches all information\r\n(id,name,address,phone,\r\narea) of a location");
            this.searchAllBtn.UseVisualStyleBackColor = false;
            this.searchAllBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // searchTypeBtn
            // 
            this.searchTypeBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.searchTypeBtn.Location = new System.Drawing.Point(3, 177);
            this.searchTypeBtn.Name = "searchTypeBtn";
            this.searchTypeBtn.Size = new System.Drawing.Size(173, 33);
            this.searchTypeBtn.TabIndex = 4;
            this.searchTypeBtn.Text = "Search By Type";
            this.toolTip1.SetToolTip(this.searchTypeBtn, "Search location specific\r\nto type. For xample\r\nby area");
            this.searchTypeBtn.UseVisualStyleBackColor = false;
            this.searchTypeBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // Searchbtn
            // 
            this.Searchbtn.Location = new System.Drawing.Point(3, 138);
            this.Searchbtn.Name = "Searchbtn";
            this.Searchbtn.Size = new System.Drawing.Size(173, 38);
            this.Searchbtn.TabIndex = 3;
            this.Searchbtn.Text = "Search All";
            this.Searchbtn.UseVisualStyleBackColor = true;
            // 
            // Deletebtn
            // 
            this.Deletebtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Deletebtn.Location = new System.Drawing.Point(3, 93);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(173, 39);
            this.Deletebtn.TabIndex = 2;
            this.Deletebtn.Text = "Delete";
            this.toolTip1.SetToolTip(this.Deletebtn, "Lets admin delete\r\nlocation information\r\n\r\n");
            this.Deletebtn.UseVisualStyleBackColor = false;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // Editbtn
            // 
            this.Editbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Editbtn.Location = new System.Drawing.Point(3, 48);
            this.Editbtn.Name = "Editbtn";
            this.Editbtn.Size = new System.Drawing.Size(173, 41);
            this.Editbtn.TabIndex = 1;
            this.Editbtn.Text = "Edit";
            this.toolTip1.SetToolTip(this.Editbtn, "Lets admin edit\r\nlocation information\r\n\r\n");
            this.Editbtn.UseVisualStyleBackColor = false;
            this.Editbtn.Click += new System.EventHandler(this.Editbtn_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Addbtn.Location = new System.Drawing.Point(3, 3);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(173, 39);
            this.Addbtn.TabIndex = 0;
            this.Addbtn.Text = "Add";
            this.toolTip1.SetToolTip(this.Addbtn, "Lets admin add new\r\nlocation information\r\n");
            this.Addbtn.UseVisualStyleBackColor = false;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Exitbtn.Location = new System.Drawing.Point(657, 335);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(120, 33);
            this.Exitbtn.TabIndex = 4;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = false;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(569, 160);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(205, 169);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(789, 380);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "StartForm";
            this.Text = "   Location Information System";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.StartForm_FormClosed);
            this.Load += new System.EventHandler(this.StartForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Adminbtn;
        private System.Windows.Forms.Button Userbtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox Passtxt;
        private System.Windows.Forms.Label Passlbl;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.Label Loginlbl;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Searchbtn;
        private System.Windows.Forms.Button Deletebtn;
        private System.Windows.Forms.Button Editbtn;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.Button Loginexitbtn;
        private System.Windows.Forms.Button Loginbackbtn;
        private System.Windows.Forms.Button searchAllBtn;
        private System.Windows.Forms.Button searchTypeBtn;
        private System.Windows.Forms.Button logOutBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button button1;
    }
}