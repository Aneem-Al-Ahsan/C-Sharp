﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace PresentationLayer
{
    public partial class DeleteForm : Form
    {
        public DeleteForm()
        {
            InitializeComponent();
            panel1.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "")
            {
                MessageBox.Show("Missing Field");
            }
            else if (listBox1.Text == "Hospital")
            {
                Hospital hospital = new Hospital();
                hospital.Id = int.Parse(DeleteTxt.Text);
                HospitalService hospitalService = new HospitalService();
                if (hospitalService.Delete(hospital) == 1)
                {
                    MessageBox.Show("Deleted");
                    panel1.Show();
                    List<Hospital> hospitalList = new List<Hospital>();
                    HospitalService hospitalService1 = new HospitalService();
                    hospitalList = hospitalService1.GetAll();
                    dataGridView1.DataSource = hospitalList;
                }
            }
            else if (listBox1.Text == "Pharmacy")
            {
                Pharmacy pharmacy = new Pharmacy();
                pharmacy.Id = int.Parse(DeleteTxt.Text);
                PharmacyService pharmacyService = new PharmacyService();
                if (pharmacyService.Delete(pharmacy) == 1)
                {
                    MessageBox.Show("Deleted");
                    panel1.Show();
                    List<Pharmacy> pharmacyList = new List<Pharmacy>();
                    PharmacyService pharmacyService1 = new PharmacyService();
                    pharmacyList = pharmacyService1.GetAll();
                    dataGridView1.DataSource = pharmacyList;
                }
            }
            else if(listBox1.Text=="Shopping Mall")
            {
                ShoppingMall shoppingMall = new ShoppingMall();
                shoppingMall.Id = int.Parse(DeleteTxt.Text);
                ShoppingMallService shoppingMallService = new ShoppingMallService();
                if (shoppingMallService.Delete(shoppingMall) == 1)
                {
                    MessageBox.Show("Deleted");
                    panel1.Show();
                    List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                    ShoppingMallService shoppingMallService1 = new ShoppingMallService();
                    shoppingMallList = shoppingMallService1.GetAll();
                    dataGridView1.DataSource = shoppingMallList;
                }
            }
            else if (listBox1.Text == "Resturaunt")
            {
                Restaurant restaurant = new Restaurant();
                restaurant.Id= int.Parse(DeleteTxt.Text);
                RestaurantService restaurantService = new RestaurantService();
                if (restaurantService.Delete(restaurant) == 1)
                {
                    MessageBox.Show("Deleted");
                    panel1.Show();
                    List<Restaurant> restaurantList = new List<Restaurant>();
                    RestaurantService restaurantService1 = new RestaurantService();
                    restaurantList = restaurantService1.GetAll();
                    dataGridView1.DataSource = restaurantList;
                }
            }
            else
            {
                Admin admin = new Admin();
                admin.Id= int.Parse(DeleteTxt.Text);
                AdminService adminService = new AdminService();
                if (adminService.Delete(admin) == 1)
                {
                    MessageBox.Show("Deleted");
                    panel1.Show();

                    List<Admin> adminList = new List<Admin>();
                    AdminService adminService1 = new AdminService();
                    adminList = adminService1.GetAll();
                    dataGridView1.DataSource = adminList;
                }
            }
        }

        private void DeleteForm_Load(object sender, EventArgs e)
        {

        }

        private void DeleteForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            //StartForm startForm = new StartForm();
            //startForm.Show();
        }

        private void deleteCloseBtn_Click(object sender, EventArgs e)
        {
            panel1.Hide();
        }
    }
}
