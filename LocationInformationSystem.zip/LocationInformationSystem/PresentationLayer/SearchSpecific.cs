﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace PresentationLayer
{
    public partial class SearchSpecific : Form
    {
        public SearchSpecific()
        {
            InitializeComponent();
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            //StartForm startForm = new StartForm();
            //startForm.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            googleMapNameTxt.Text = dataGridView1["Name", e.RowIndex].Value.ToString();
            googleMapAreaTxt.Text = SpecificTypeTxt.Text;
        }

        private void googlSearchBtn_Click(object sender, EventArgs e)
        {

            string name = googleMapNameTxt.Text;
            string area = googleMapAreaTxt.Text;
            StringBuilder queryAddress = new StringBuilder();
            queryAddress.Append("https://www.google.com/maps?q=");
            if (name != string.Empty)
            {
                queryAddress.Append(name + "," + "+");
            }
            if (area != string.Empty)
            {
                queryAddress.Append(area + "," + "+");
            }
            webBrowser1.Navigate(queryAddress.ToString());
        }

        private void SpecificTypeTxt_TextChanged(object sender, EventArgs e)
        {
            if (listBox1.Text == "" || listBox2.Text == " " || SpecificTypeTxt.Text == "")
            {
                MessageBox.Show("Missing Field");

            }
            else if (listBox1.Text == "Hospital")
            {
                if (listBox2.Text == "Area")
                {
                    Hospital hospital = new Hospital();
                    List<Hospital> hospitalList = new List<Hospital>();
                    hospital.Area = SpecificTypeTxt.Text.ToLower();
                    HospitalService hospitalService = new HospitalService();
                    hospitalList = hospitalService.GetByArea(hospital);
                    dataGridView1.DataSource = hospitalList;
                }
            }
            else if (listBox1.Text == "Pharmacy")
            {
                if (listBox2.Text == "Area")
                {
                    Pharmacy pharmacy = new Pharmacy();
                    List<Pharmacy> pharmacyList = new List<Pharmacy>();
                    pharmacy.Area = (SpecificTypeTxt.Text).ToLower();
                    PharmacyService pharmacyService = new PharmacyService();
                    pharmacyList = pharmacyService.GetByArea(pharmacy);
                    dataGridView1.DataSource = pharmacyList;
                }
            }
            else if (listBox1.Text == "Shopping Mall")
            {
                if (listBox2.Text == "Area")
                {
                    ShoppingMall shoppingMall = new ShoppingMall();
                    List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                    shoppingMall.Area = (SpecificTypeTxt.Text).ToLower();
                    ShoppingMallService shoppingMallService = new ShoppingMallService();
                    shoppingMallList = shoppingMallService.GetByArea(shoppingMall);
                    dataGridView1.DataSource = shoppingMallList;
                }
            }
            else
            {
                if (listBox2.Text == "Area")
                {
                    Restaurant restaurant = new Restaurant();
                    List<Restaurant> restaurantList = new List<Restaurant>();
                    restaurant.Area = (SpecificTypeTxt.Text).ToLower();
                    RestaurantService restaurantService = new RestaurantService();
                    restaurantList = restaurantService.GetByArea(restaurant);
                    dataGridView1.DataSource = restaurantList;
                }
            }

        }
    }
}
