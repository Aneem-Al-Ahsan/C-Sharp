﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace PresentationLayer
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
            Adminpasswordtxt.PasswordChar = '*';
            Confirmpasswordtxt.PasswordChar = '*';
        }
        

        private void AddForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void AddForm_Load(object sender, EventArgs e)
        {

        }

        private void Catagorybackbtn_Click(object sender, EventArgs e)
        {
            //StartForm startForm = new StartForm();
            this.Hide();
            //startForm.Show();
        }

        private void CatagoryselectbtnCatagoryselectbtn_Click(object sender, EventArgs e)
        {
            //if (ListBox1.Text == "")
            //{
            //    MessageBox.Show("Must choose a catagory");
            //    panel1.Show();
            //}
            //else if (ListBox1.Text == "admin")
            //{
            //    panel3.Show();
            //}
            //else
            //{
            //    panel2.Show();
            //}
        }

        private void Informationselectbtn_Click(object sender, EventArgs e)
        {
            if (ListBox1.Text == "hospital")
            {
                Hospital hospital = new Hospital();
                hospital.Id = int.Parse(Idtxt.Text);
                hospital.Name = (Nametxt.Text).ToLower();
                hospital.Address = (Addresstxt.Text).ToLower();
                hospital.Phone = (Phonetxt.Text).ToLower();
                hospital.Area = (Areatxt.Text).ToLower();
                HospitalService hospitalService = new HospitalService();
                if (hospitalService.Add(hospital) > 0)
                {
                    MessageBox.Show("Record Added");
                    panel4.Show();
                    List<Hospital> hospitalList = new List<Hospital>();
                    HospitalService hospitalService1 = new HospitalService();
                    hospitalList = hospitalService1.GetAll();
                    dataGridView1.DataSource = hospitalList;
                }
                
            }
            else if (ListBox1.Text == "pharmacy")
            {
                Pharmacy pharmacy = new Pharmacy();
                pharmacy.Id = int.Parse(Idtxt.Text);
                pharmacy.Name = (Nametxt.Text).ToLower();
                pharmacy.Address = (Addresstxt.Text).ToLower();
                pharmacy.Phone = (Phonetxt.Text).ToLower();
                pharmacy.Area = (Areatxt.Text).ToLower();
                PharmacyService pharmacyService = new PharmacyService();
                if (pharmacyService.Add(pharmacy) > 0)
                {
                    MessageBox.Show("Record Added");
                    panel4.Show();
                    List<Pharmacy> pharmacyList = new List<Pharmacy>();
                    PharmacyService pharmacyService1 = new PharmacyService();
                    pharmacyList = pharmacyService1.GetAll();
                    dataGridView1.DataSource = pharmacyList;
                }
                
            }
            else if (ListBox1.Text == "shoppingmall")
            {
                ShoppingMall shoppingmall = new ShoppingMall();
                shoppingmall.Id = int.Parse(Idtxt.Text);
                shoppingmall.Name = (Nametxt.Text).ToLower();
                shoppingmall.Address = (Addresstxt.Text).ToLower();
                shoppingmall.Phone = (Phonetxt.Text).ToLower();
                shoppingmall.Area = (Areatxt.Text).ToLower();
                ShoppingMallService shoppingMallService = new ShoppingMallService();
                if (shoppingMallService.Add(shoppingmall) > 0)
                {
                    MessageBox.Show("Record Added");
                    panel4.Show();
                    List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                    ShoppingMallService shoppingMallService1 = new ShoppingMallService();
                    shoppingMallList = shoppingMallService1.GetAll();
                    dataGridView1.DataSource = shoppingMallList;
                }
                
            }
            else
            {
                Restaurant restaurant = new Restaurant();
                restaurant.Id = int.Parse(Idtxt.Text);
                restaurant.Name = (Nametxt.Text).ToLower();
                restaurant.Address = (Addresstxt.Text).ToLower();
                restaurant.Phone = (Phonetxt.Text).ToLower();
                restaurant.Area = (Areatxt.Text).ToLower();
                RestaurantService restaurantService = new RestaurantService();
                if (restaurantService.Add(restaurant) > 0)
                {
                    MessageBox.Show("Record Added");
                    panel4.Show();
                    List<Restaurant> restaurantList = new List<Restaurant>();
                    RestaurantService restaurantService1 = new RestaurantService();
                    restaurantList = restaurantService1.GetAll();
                    dataGridView1.DataSource = restaurantList;
                }

            }

        }

        private void Informationbackbtn_Click(object sender, EventArgs e)
        {
            panel2.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Adminnametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Adminbackbtn_Click(object sender, EventArgs e)
        {
            panel3.Hide();
        }

        private void Adminaddbtn_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin();
            AdminService adminService = new AdminService();
            admin.Id = int.Parse(AdminIdtxt.Text);
            admin.Name = Adminnametxt.Text;
            admin.Password = Adminpasswordtxt.Text;
            if (admin.Password != Confirmpasswordtxt.Text)
            {
                MessageBox.Show("Password doesnot match");
            }
            else
            {
                if (adminService.Add(admin) > 0 && admin.Password == Confirmpasswordtxt.Text)
                {
                    MessageBox.Show("Record Added");
                    panel4.Show();

                    List<Admin> adminList = new List<Admin>();
                    AdminService adminService1 = new AdminService();
                    adminList = adminService1.GetAll();
                    dataGridView1.DataSource = adminList;
                }
            }
        }

        private void Adminpasswordtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void addGridViewBtn_Click(object sender, EventArgs e)
        {
            panel4.Hide();
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBox1.Text == "")
            {
                MessageBox.Show("Must choose a catagory");
                panel1.Show();
            }
            else if (ListBox1.Text == "admin")
            {
                panel2.Hide();
                panel3.Show();
            }
            else
            {
                panel2.Show();
            }
        }
    }
}
