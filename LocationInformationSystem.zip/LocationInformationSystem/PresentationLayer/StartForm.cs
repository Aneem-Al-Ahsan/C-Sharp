﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using BusinessAccessLayer;
using System.Windows.Forms;

namespace PresentationLayer
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
            Passtxt.PasswordChar = '*';
            button1.Hide();
        }

        private void StartForm_Load(object sender, EventArgs e)
        {
            panel2.Hide();
            panel3.Hide();
        }

        private void StartForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Adminbtn_Click(object sender, EventArgs e)
        {
            panel2.Show();
           
           
        }

        private void Loginbackbtn_Click(object sender, EventArgs e)
        {
            
            Addbtn.Show();
            Deletebtn.Show();
            Editbtn.Show();
            logOutBtn.Show();
            panel3.Hide();
            AdminService adminService = new AdminService();
            Admin admin = new Admin();
            List<Admin> adminList = new List<Admin>();
            adminList = adminService.GetAll();
            for(int i = 0; i < adminList.Count; i++)
            {
                if(adminList[i].Name==Nametxt.Text && adminList[i].Password == Passtxt.Text)
                {
                    panel3.Show();
                }
                
            }
           
        }

        private void Loginexitbtn_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            panel3.Hide();
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            //this.Hide();
            AddForm addForm = new AddForm();
            addForm.Show();
        }

        private void Editbtn_Click(object sender, EventArgs e)
        {
            //this.Hide();
            EditForm editForm = new EditForm();
            editForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.Hide();
            SearchSpecific searchSpecific = new SearchSpecific();
            searchSpecific.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //this.Hide();
            SearchAll searchAll = new SearchAll();
            searchAll.Show();
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            DeleteForm deleteForm = new DeleteForm();
            //this.Hide();
            deleteForm.Show();
        }

        private void Userbtn_Click(object sender, EventArgs e)
        {
            panel3.Show();
            Addbtn.Hide();
            Deletebtn.Hide();
            Editbtn.Hide();
            logOutBtn.Hide();
            button1.Show();
        }

        private void logOutBtn_Click(object sender, EventArgs e)
        {
            Nametxt.Text = "";
            Passtxt.Text = "";
            panel2.Hide();
            panel3.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            panel3.Hide();
        }

        private void Selectbtn_Click(object sender, EventArgs e)
        {

        }
    }
}

