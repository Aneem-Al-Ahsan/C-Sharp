﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace PresentationLayer
{
    public partial class EditForm : Form
    {
        public EditForm()
        {
            InitializeComponent();
            panel2.Hide();
            panel3.Hide();
            panel4.Hide();
        }

        private void EditForm_Load(object sender, EventArgs e)
        {

        }

        private void EditForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Selectbtn_Click(object sender, EventArgs e)
        {
            //if (listBox1.Text == "")
            //{
            //    MessageBox.Show("Must choose a catagory");
            //}
            //else if (listBox1.Text == "admin")
            //{
            //    panel3.Show();
            //}
            //else
            //{
            //    panel2.Show();
            //}
        }

        private void Udpatetxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            //StartForm startForm = new StartForm();
            //startForm.Show();
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            if (Fieldoption.Text == "" || Idtxt.Text == "" || Updatetxt.Text == "")
            {
                MessageBox.Show("Incomplete fields");
            }
            else if (listBox1.Text == "hospital")
            {
                if (Fieldoption.Text == "Name")
                {
                    Hospital hospital = new Hospital();
                    HospitalService hospitalService = new HospitalService();
                    hospital.Id = int.Parse(Idtxt.Text);
                    hospital.Name = (Updatetxt.Text).ToLower();
                    if (hospitalService.EditName(hospital) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Hospital> hospitalList = new List<Hospital>();
                        HospitalService hospitalService1 = new HospitalService();
                        hospitalList = hospitalService1.GetAll();
                        dataGridView1.DataSource = hospitalList;
                    }
                }
                else if (Fieldoption.Text == "Address")
                {
                    Hospital hospital = new Hospital();
                    HospitalService hospitalService = new HospitalService();
                    hospital.Id = int.Parse(Idtxt.Text);
                    hospital.Address = (Updatetxt.Text).ToLower();
                    if (hospitalService.EditAddress(hospital) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Hospital> hospitalList = new List<Hospital>();
                        HospitalService hospitalService1 = new HospitalService();
                        hospitalList = hospitalService1.GetAll();
                        dataGridView1.DataSource = hospitalList;
                    }
                }
                else if (Fieldoption.Text == "Phone")
                {
                    Hospital hospital = new Hospital();
                    HospitalService hospitalService = new HospitalService();
                    hospital.Id = int.Parse(Idtxt.Text);
                    hospital.Phone = (Updatetxt.Text).ToLower();
                    if (hospitalService.EditPhone(hospital) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Hospital> hospitalList = new List<Hospital>();
                        HospitalService hospitalService1 = new HospitalService();
                        hospitalList = hospitalService1.GetAll();
                        dataGridView1.DataSource = hospitalList;
                    }
                }
                else
                {
                    Hospital hospital = new Hospital();
                    HospitalService hospitalService = new HospitalService();
                    hospital.Id = int.Parse(Idtxt.Text);
                    hospital.Area = (Updatetxt.Text).ToLower();
                    if (hospitalService.EditArea(hospital) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Hospital> hospitalList = new List<Hospital>();
                        HospitalService hospitalService1 = new HospitalService();
                        hospitalList = hospitalService1.GetAll();
                        dataGridView1.DataSource = hospitalList;
                    }
                }
            }
            else if (listBox1.Text == "pharmacy")
            {
                if (Fieldoption.Text == "Name")
                {
                    Pharmacy pharmacy = new Pharmacy();
                    PharmacyService pharmacyService = new PharmacyService();
                    pharmacy.Id = int.Parse(Idtxt.Text);
                    pharmacy.Name = (Updatetxt.Text).ToLower();
                    if (pharmacyService.EditName(pharmacy) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Pharmacy> pharmacyList = new List<Pharmacy>();
                        PharmacyService pharmacyService1 = new PharmacyService();
                        pharmacyList = pharmacyService1.GetAll();
                        dataGridView1.DataSource = pharmacyList;
                    }
                }
                else if (Fieldoption.Text == "Address")
                {
                    Pharmacy pharmacy = new Pharmacy();
                    PharmacyService pharmacyService = new PharmacyService();
                    pharmacy.Id = int.Parse(Idtxt.Text);
                    pharmacy.Address = (Updatetxt.Text).ToLower();
                    if (pharmacyService.EditAddress(pharmacy) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Pharmacy> pharmacyList = new List<Pharmacy>();
                        PharmacyService pharmacyService1 = new PharmacyService();
                        pharmacyList = pharmacyService1.GetAll();
                        dataGridView1.DataSource = pharmacyList;
                    }
                }
                else if (Fieldoption.Text == "Phone")
                {
                    Pharmacy pharmacy = new Pharmacy();
                    PharmacyService pharmacyService = new PharmacyService();
                    pharmacy.Id = int.Parse(Idtxt.Text);
                    pharmacy.Phone = (Updatetxt.Text).ToLower();
                    if (pharmacyService.EditPhone(pharmacy) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Pharmacy> pharmacyList = new List<Pharmacy>();
                        PharmacyService pharmacyService1 = new PharmacyService();
                        pharmacyList = pharmacyService1.GetAll();
                        dataGridView1.DataSource = pharmacyList;
                    }
                }
                else
                {
                    Pharmacy pharmacy = new Pharmacy();
                    PharmacyService pharmacyService = new PharmacyService();
                    pharmacy.Id = int.Parse(Idtxt.Text);
                    pharmacy.Area = (Updatetxt.Text).ToLower();
                    if (pharmacyService.EditArea(pharmacy) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Pharmacy> pharmacyList = new List<Pharmacy>();
                        PharmacyService pharmacyService1 = new PharmacyService();
                        pharmacyList = pharmacyService1.GetAll();
                        dataGridView1.DataSource = pharmacyList;
                    }
                }
            }
            else if (listBox1.Text == "shoppingmall")
            {

                if (Fieldoption.Text == "Name")
                {
                    ShoppingMall shoppingMall = new ShoppingMall();
                    ShoppingMallService shoppingMallService = new ShoppingMallService();
                    shoppingMall.Id = int.Parse(Idtxt.Text);
                    shoppingMall.Name = (Updatetxt.Text).ToLower();
                    if (shoppingMallService.EditName(shoppingMall) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                        ShoppingMallService shoppingMallService1 = new ShoppingMallService();
                        shoppingMallList = shoppingMallService1.GetAll();
                        dataGridView1.DataSource = shoppingMallList;
                    }
                }
                else if (Fieldoption.Text == "Address")
                {
                    ShoppingMall shoppingMall = new ShoppingMall();
                    ShoppingMallService shoppingMallService = new ShoppingMallService();
                    shoppingMall.Id = int.Parse(Idtxt.Text);
                    shoppingMall.Address = (Updatetxt.Text).ToLower();
                    if (shoppingMallService.EditAddress(shoppingMall) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                        ShoppingMallService shoppingMallService1 = new ShoppingMallService();
                        shoppingMallList = shoppingMallService1.GetAll();
                        dataGridView1.DataSource = shoppingMallList;
                    }
                }
                else if (Fieldoption.Text == "Phone")
                {
                    ShoppingMall shoppingMall = new ShoppingMall();
                    ShoppingMallService shoppingMallService = new ShoppingMallService();
                    shoppingMall.Id = int.Parse(Idtxt.Text);
                    shoppingMall.Phone = (Updatetxt.Text).ToLower();
                    if (shoppingMallService.EditPhone(shoppingMall) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                        ShoppingMallService shoppingMallService1 = new ShoppingMallService();
                        shoppingMallList = shoppingMallService1.GetAll();
                        dataGridView1.DataSource = shoppingMallList;
                    }
                }
                else 
                {
                    ShoppingMall shoppingMall = new ShoppingMall();
                    ShoppingMallService shoppingMallService = new ShoppingMallService();
                    shoppingMall.Id = int.Parse(Idtxt.Text);
                    shoppingMall.Area = (Updatetxt.Text).ToLower();
                    if (shoppingMallService.EditArea(shoppingMall) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                        ShoppingMallService shoppingMallService1 = new ShoppingMallService();
                        shoppingMallList = shoppingMallService1.GetAll();
                        dataGridView1.DataSource = shoppingMallList;
                    }
                }
            }
            else 
            {
                if (Fieldoption.Text == "Name")
                {
                    Restaurant restaurant = new Restaurant();
                    RestaurantService restaurantService = new RestaurantService();
                    restaurant.Id = int.Parse(Idtxt.Text);
                    restaurant.Name = (Updatetxt.Text).ToLower();
                    if (restaurantService.EditName(restaurant) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Restaurant> restaurantList = new List<Restaurant>();
                        RestaurantService restaurantService1 = new RestaurantService();
                        restaurantList = restaurantService1.GetAll();
                        dataGridView1.DataSource = restaurantList;
                    }
                }
                else if (Fieldoption.Text == "Address")
                {
                    Restaurant restaurant = new Restaurant();
                    RestaurantService restaurantService = new RestaurantService();
                    restaurant.Id = int.Parse(Idtxt.Text);
                    restaurant.Address = (Updatetxt.Text).ToLower();
                    if (restaurantService.EditAddress(restaurant) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Restaurant> restaurantList = new List<Restaurant>();
                        RestaurantService restaurantService1 = new RestaurantService();
                        restaurantList = restaurantService1.GetAll();
                        dataGridView1.DataSource = restaurantList;
                    }
                }
                else if (Fieldoption.Text == "Phone")
                {
                    Restaurant restaurant = new Restaurant();
                    RestaurantService restaurantService = new RestaurantService();
                    restaurant.Id = int.Parse(Idtxt.Text);
                    restaurant.Phone = (Updatetxt.Text).ToLower();
                    if (restaurantService.EditPhone(restaurant) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Restaurant> restaurantList = new List<Restaurant>();
                        RestaurantService restaurantService1 = new RestaurantService();
                        restaurantList = restaurantService1.GetAll();
                        dataGridView1.DataSource = restaurantList;
                    }
                }
                else 
                {
                    Restaurant restaurant = new Restaurant();
                    RestaurantService restaurantService = new RestaurantService();
                    restaurant.Id = int.Parse(Idtxt.Text);
                    restaurant.Area = (Updatetxt.Text).ToLower();
                    if (restaurantService.EditArea(restaurant) == 1)
                    {
                        MessageBox.Show("Record Updated");
                        panel4.Show();
                        List<Restaurant> restaurantList = new List<Restaurant>();
                        RestaurantService restaurantService1 = new RestaurantService();
                        restaurantList = restaurantService1.GetAll();
                        dataGridView1.DataSource = restaurantList;
                    }
                }
            }
            
        }

        private void Back1btn_Click(object sender, EventArgs e)
        {
            panel3.Hide();
        }


       

        private void button1_Click_1(object sender, EventArgs e)
        {
          
        }

        private void Backbtn1_Click(object sender, EventArgs e)
        {
            panel2.Hide();
        }

        private void AdminBackBtn_Click(object sender, EventArgs e)
        {

        }

        private void AdminUpdateBtn_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text=="" || AdminIdTxt.Text == "" || AdminPasswordTxt.Text == "" || AdminNameTxt.Text == "")
            {
                MessageBox.Show("Missing Fields");
            }
            else if (comboBox1.Text == "Name")
            {
                Admin admin = new Admin();
                AdminService adminService = new AdminService();
                admin.Id = int.Parse(AdminIdTxt.Text);
                admin.Name = AdminNameTxt.Text;
                admin.Password = AdminPasswordTxt.Text;
                if (adminService.EditName(admin) == 1)
                {
                    MessageBox.Show("Record Updated");
                    panel4.Show();

                    List<Admin> adminList = new List<Admin>();
                    AdminService adminService1 = new AdminService();
                    adminList = adminService1.GetAll();
                    dataGridView1.DataSource = adminList;
                }
            }
            else
            {
                Admin admin = new Admin();
                AdminService adminService = new AdminService();
                admin.Id = int.Parse(AdminIdTxt.Text);
                admin.Password = AdminNameTxt.Text;
                admin.Name = AdminPasswordTxt.Text;
                if (adminService.EditPassword(admin) == 1)
                {
                    MessageBox.Show("Record Updated");
                    panel4.Show();

                    List<Admin> adminList = new List<Admin>();
                    AdminService adminService1 = new AdminService();
                    adminList = adminService1.GetAll();
                    dataGridView1.DataSource = adminList;
                }
            }
        }

        private void editCloseBtn_Click(object sender, EventArgs e)
        {
            panel4.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.Text == "")
            {
                MessageBox.Show("Must choose a catagory");
            }
            else if (listBox1.Text == "admin")
            {
                panel2.Hide();
                panel3.Show();
            }
            else
            {
                panel2.Show();
            }
        }
    }
}
