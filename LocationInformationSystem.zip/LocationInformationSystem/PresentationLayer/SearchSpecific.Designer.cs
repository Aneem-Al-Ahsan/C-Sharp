﻿namespace PresentationLayer
{
    partial class SearchSpecific
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.SpecificCatagoryLbl = new System.Windows.Forms.Label();
            this.SpecificFieldLbl = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.BackBtn = new System.Windows.Forms.Button();
            this.TypeTxt = new System.Windows.Forms.Label();
            this.SpecificTypeTxt = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.googleMapNameTxt = new System.Windows.Forms.TextBox();
            this.googleMapAreaTxt = new System.Windows.Forms.TextBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.googlSearchBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "Hospital",
            "Pharmacy",
            "Shopping Mall",
            "Resturaunt"});
            this.listBox1.Location = new System.Drawing.Point(12, 37);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 108);
            this.listBox1.TabIndex = 0;
            this.toolTip1.SetToolTip(this.listBox1, "Select location catagory\r\nhospital,pharmacy etc");
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Items.AddRange(new object[] {
            "Area"});
            this.listBox2.Location = new System.Drawing.Point(157, 37);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 108);
            this.listBox2.TabIndex = 1;
            this.toolTip1.SetToolTip(this.listBox2, "select searcg type.\r\nFor eample area");
            // 
            // SpecificCatagoryLbl
            // 
            this.SpecificCatagoryLbl.AutoSize = true;
            this.SpecificCatagoryLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpecificCatagoryLbl.Location = new System.Drawing.Point(12, 9);
            this.SpecificCatagoryLbl.Name = "SpecificCatagoryLbl";
            this.SpecificCatagoryLbl.Size = new System.Drawing.Size(101, 13);
            this.SpecificCatagoryLbl.TabIndex = 2;
            this.SpecificCatagoryLbl.Text = "Search Catagory";
            // 
            // SpecificFieldLbl
            // 
            this.SpecificFieldLbl.AutoSize = true;
            this.SpecificFieldLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpecificFieldLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SpecificFieldLbl.Location = new System.Drawing.Point(154, 9);
            this.SpecificFieldLbl.Name = "SpecificFieldLbl";
            this.SpecificFieldLbl.Size = new System.Drawing.Size(79, 13);
            this.SpecificFieldLbl.TabIndex = 3;
            this.SpecificFieldLbl.Text = "Search Type";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.Silver;
            this.dataGridView1.Location = new System.Drawing.Point(12, 151);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(445, 167);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.BackBtn.Location = new System.Drawing.Point(12, 361);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(75, 23);
            this.BackBtn.TabIndex = 6;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // TypeTxt
            // 
            this.TypeTxt.AutoSize = true;
            this.TypeTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeTxt.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TypeTxt.Location = new System.Drawing.Point(307, 9);
            this.TypeTxt.Name = "TypeTxt";
            this.TypeTxt.Size = new System.Drawing.Size(67, 13);
            this.TypeTxt.TabIndex = 7;
            this.TypeTxt.Text = "Enter Area\r\n";
            // 
            // SpecificTypeTxt
            // 
            this.SpecificTypeTxt.BackColor = System.Drawing.Color.White;
            this.SpecificTypeTxt.Location = new System.Drawing.Point(310, 37);
            this.SpecificTypeTxt.Name = "SpecificTypeTxt";
            this.SpecificTypeTxt.Size = new System.Drawing.Size(147, 20);
            this.SpecificTypeTxt.TabIndex = 8;
            this.toolTip1.SetToolTip(this.SpecificTypeTxt, "Enter area name");
            this.SpecificTypeTxt.TextChanged += new System.EventHandler(this.SpecificTypeTxt_TextChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(463, 9);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.googlSearchBtn);
            this.splitContainer1.Panel1.Controls.Add(this.googleMapAreaTxt);
            this.splitContainer1.Panel1.Controls.Add(this.googleMapNameTxt);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.webBrowser1);
            this.splitContainer1.Size = new System.Drawing.Size(646, 363);
            this.splitContainer1.SplitterDistance = 215;
            this.splitContainer1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Area";
            // 
            // googleMapNameTxt
            // 
            this.googleMapNameTxt.Location = new System.Drawing.Point(67, 28);
            this.googleMapNameTxt.Name = "googleMapNameTxt";
            this.googleMapNameTxt.Size = new System.Drawing.Size(145, 20);
            this.googleMapNameTxt.TabIndex = 2;
            this.toolTip1.SetToolTip(this.googleMapNameTxt, "enter name of location\r\n");
            this.googleMapNameTxt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // googleMapAreaTxt
            // 
            this.googleMapAreaTxt.Location = new System.Drawing.Point(67, 105);
            this.googleMapAreaTxt.Name = "googleMapAreaTxt";
            this.googleMapAreaTxt.Size = new System.Drawing.Size(145, 20);
            this.googleMapAreaTxt.TabIndex = 3;
            this.toolTip1.SetToolTip(this.googleMapAreaTxt, "enter name of location\r\narea");
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(427, 363);
            this.webBrowser1.TabIndex = 0;
            // 
            // googlSearchBtn
            // 
            this.googlSearchBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.googlSearchBtn.Location = new System.Drawing.Point(67, 191);
            this.googlSearchBtn.Name = "googlSearchBtn";
            this.googlSearchBtn.Size = new System.Drawing.Size(75, 23);
            this.googlSearchBtn.TabIndex = 10;
            this.googlSearchBtn.Text = "Go";
            this.toolTip1.SetToolTip(this.googlSearchBtn, "do google search");
            this.googlSearchBtn.UseVisualStyleBackColor = false;
            this.googlSearchBtn.Click += new System.EventHandler(this.googlSearchBtn_Click);
            // 
            // SearchSpecific
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(1121, 384);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.SpecificTypeTxt);
            this.Controls.Add(this.TypeTxt);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.SpecificFieldLbl);
            this.Controls.Add(this.SpecificCatagoryLbl);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Name = "SearchSpecific";
            this.Text = "SearchSpecific";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label SpecificCatagoryLbl;
        private System.Windows.Forms.Label SpecificFieldLbl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label TypeTxt;
        private System.Windows.Forms.TextBox SpecificTypeTxt;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox googleMapNameTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox googleMapAreaTxt;
        private System.Windows.Forms.Button googlSearchBtn;
        private System.Windows.Forms.WebBrowser webBrowser1;
    }
}