﻿namespace PresentationLayer
{
    partial class EditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbtn = new System.Windows.Forms.Button();
            this.Selectbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Updatetxt = new System.Windows.Forms.TextBox();
            this.Newlbl = new System.Windows.Forms.Label();
            this.Idtxt = new System.Windows.Forms.TextBox();
            this.idlbl = new System.Windows.Forms.Label();
            this.Selectlbl = new System.Windows.Forms.Label();
            this.Fieldoption = new System.Windows.Forms.ComboBox();
            this.Backbtn1 = new System.Windows.Forms.Button();
            this.Updatebtn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.AdminUpdateBtn = new System.Windows.Forms.Button();
            this.AdminIdTxt = new System.Windows.Forms.TextBox();
            this.AdminIdLbl = new System.Windows.Forms.Label();
            this.AdminBackBtn = new System.Windows.Forms.Button();
            this.AdminPasswordTxt = new System.Windows.Forms.TextBox();
            this.AdminPasswordLbl = new System.Windows.Forms.Label();
            this.AdminNameTxt = new System.Windows.Forms.TextBox();
            this.AdminNameLbl = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.editCloseBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel1.Controls.Add(this.Backbtn);
            this.panel1.Controls.Add(this.Selectbtn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Location = new System.Drawing.Point(3, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(290, 299);
            this.panel1.TabIndex = 0;
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Backbtn.Location = new System.Drawing.Point(212, 273);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.Size = new System.Drawing.Size(75, 23);
            this.Backbtn.TabIndex = 3;
            this.Backbtn.Text = "Back";
            this.Backbtn.UseVisualStyleBackColor = false;
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // Selectbtn
            // 
            this.Selectbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Selectbtn.Location = new System.Drawing.Point(0, 273);
            this.Selectbtn.Name = "Selectbtn";
            this.Selectbtn.Size = new System.Drawing.Size(75, 23);
            this.Selectbtn.TabIndex = 2;
            this.Selectbtn.Text = "Select";
            this.Selectbtn.UseVisualStyleBackColor = false;
            this.Selectbtn.Click += new System.EventHandler(this.Selectbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(86, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Catagory";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Items.AddRange(new object[] {
            "hospital",
            "pharmacy",
            "shoppingmall",
            "resturaunt",
            "admin"});
            this.listBox1.Location = new System.Drawing.Point(89, 41);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 180);
            this.listBox1.TabIndex = 0;
            this.toolTip1.SetToolTip(this.listBox1, "select location catagory\r\nhospital, pharmacy etc");
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel2.Controls.Add(this.Updatetxt);
            this.panel2.Controls.Add(this.Newlbl);
            this.panel2.Controls.Add(this.Idtxt);
            this.panel2.Controls.Add(this.idlbl);
            this.panel2.Controls.Add(this.Selectlbl);
            this.panel2.Controls.Add(this.Fieldoption);
            this.panel2.Controls.Add(this.Backbtn1);
            this.panel2.Controls.Add(this.Updatebtn);
            this.panel2.Location = new System.Drawing.Point(312, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(395, 296);
            this.panel2.TabIndex = 1;
            // 
            // Updatetxt
            // 
            this.Updatetxt.BackColor = System.Drawing.Color.White;
            this.Updatetxt.Location = new System.Drawing.Point(88, 203);
            this.Updatetxt.Name = "Updatetxt";
            this.Updatetxt.Size = new System.Drawing.Size(229, 20);
            this.Updatetxt.TabIndex = 10;
            this.toolTip1.SetToolTip(this.Updatetxt, "Enter the new information");
            this.Updatetxt.TextChanged += new System.EventHandler(this.Udpatetxt_TextChanged);
            // 
            // Newlbl
            // 
            this.Newlbl.AutoSize = true;
            this.Newlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Newlbl.Location = new System.Drawing.Point(3, 203);
            this.Newlbl.Name = "Newlbl";
            this.Newlbl.Size = new System.Drawing.Size(39, 16);
            this.Newlbl.TabIndex = 9;
            this.Newlbl.Text = "Enter";
            // 
            // Idtxt
            // 
            this.Idtxt.BackColor = System.Drawing.Color.White;
            this.Idtxt.Location = new System.Drawing.Point(88, 103);
            this.Idtxt.Name = "Idtxt";
            this.Idtxt.Size = new System.Drawing.Size(229, 20);
            this.Idtxt.TabIndex = 8;
            this.toolTip1.SetToolTip(this.Idtxt, "enter location\'s ID");
            // 
            // idlbl
            // 
            this.idlbl.AutoSize = true;
            this.idlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idlbl.Location = new System.Drawing.Point(3, 104);
            this.idlbl.Name = "idlbl";
            this.idlbl.Size = new System.Drawing.Size(55, 16);
            this.idlbl.TabIndex = 7;
            this.idlbl.Text = "Enter ID";
            // 
            // Selectlbl
            // 
            this.Selectlbl.AutoSize = true;
            this.Selectlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Selectlbl.Location = new System.Drawing.Point(3, 7);
            this.Selectlbl.Name = "Selectlbl";
            this.Selectlbl.Size = new System.Drawing.Size(79, 16);
            this.Selectlbl.TabIndex = 4;
            this.Selectlbl.Text = "Select Field";
            // 
            // Fieldoption
            // 
            this.Fieldoption.BackColor = System.Drawing.Color.White;
            this.Fieldoption.FormattingEnabled = true;
            this.Fieldoption.Items.AddRange(new object[] {
            "Name",
            "Address",
            "Phone",
            "Area"});
            this.Fieldoption.Location = new System.Drawing.Point(88, 7);
            this.Fieldoption.Name = "Fieldoption";
            this.Fieldoption.Size = new System.Drawing.Size(229, 21);
            this.Fieldoption.TabIndex = 6;
            this.toolTip1.SetToolTip(this.Fieldoption, "Choose edit field\r\nname, area etc");
            this.Fieldoption.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Backbtn1
            // 
            this.Backbtn1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Backbtn1.Location = new System.Drawing.Point(315, 271);
            this.Backbtn1.Name = "Backbtn1";
            this.Backbtn1.Size = new System.Drawing.Size(75, 23);
            this.Backbtn1.TabIndex = 5;
            this.Backbtn1.Text = "Back";
            this.Backbtn1.UseVisualStyleBackColor = false;
            this.Backbtn1.Click += new System.EventHandler(this.Backbtn1_Click);
            // 
            // Updatebtn
            // 
            this.Updatebtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Updatebtn.Location = new System.Drawing.Point(0, 271);
            this.Updatebtn.Name = "Updatebtn";
            this.Updatebtn.Size = new System.Drawing.Size(75, 23);
            this.Updatebtn.TabIndex = 4;
            this.Updatebtn.Text = "Update";
            this.Updatebtn.UseVisualStyleBackColor = false;
            this.Updatebtn.Click += new System.EventHandler(this.Updatebtn_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel3.Controls.Add(this.AdminUpdateBtn);
            this.panel3.Controls.Add(this.AdminIdTxt);
            this.panel3.Controls.Add(this.AdminIdLbl);
            this.panel3.Controls.Add(this.AdminBackBtn);
            this.panel3.Controls.Add(this.AdminPasswordTxt);
            this.panel3.Controls.Add(this.AdminPasswordLbl);
            this.panel3.Controls.Add(this.AdminNameTxt);
            this.panel3.Controls.Add(this.AdminNameLbl);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(713, 14);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(258, 294);
            this.panel3.TabIndex = 2;
            // 
            // AdminUpdateBtn
            // 
            this.AdminUpdateBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.AdminUpdateBtn.Location = new System.Drawing.Point(3, 268);
            this.AdminUpdateBtn.Name = "AdminUpdateBtn";
            this.AdminUpdateBtn.Size = new System.Drawing.Size(75, 23);
            this.AdminUpdateBtn.TabIndex = 17;
            this.AdminUpdateBtn.Text = "Update";
            this.AdminUpdateBtn.UseVisualStyleBackColor = false;
            this.AdminUpdateBtn.Click += new System.EventHandler(this.AdminUpdateBtn_Click);
            // 
            // AdminIdTxt
            // 
            this.AdminIdTxt.BackColor = System.Drawing.Color.White;
            this.AdminIdTxt.Location = new System.Drawing.Point(93, 107);
            this.AdminIdTxt.Name = "AdminIdTxt";
            this.AdminIdTxt.Size = new System.Drawing.Size(149, 20);
            this.AdminIdTxt.TabIndex = 16;
            this.toolTip1.SetToolTip(this.AdminIdTxt, "enter admin ID");
            // 
            // AdminIdLbl
            // 
            this.AdminIdLbl.AutoSize = true;
            this.AdminIdLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminIdLbl.Location = new System.Drawing.Point(10, 107);
            this.AdminIdLbl.Name = "AdminIdLbl";
            this.AdminIdLbl.Size = new System.Drawing.Size(21, 16);
            this.AdminIdLbl.TabIndex = 15;
            this.AdminIdLbl.Text = "ID";
            // 
            // AdminBackBtn
            // 
            this.AdminBackBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.AdminBackBtn.Location = new System.Drawing.Point(180, 268);
            this.AdminBackBtn.Name = "AdminBackBtn";
            this.AdminBackBtn.Size = new System.Drawing.Size(75, 23);
            this.AdminBackBtn.TabIndex = 14;
            this.AdminBackBtn.Text = "Back";
            this.AdminBackBtn.UseVisualStyleBackColor = false;
            this.AdminBackBtn.Click += new System.EventHandler(this.AdminBackBtn_Click);
            // 
            // AdminPasswordTxt
            // 
            this.AdminPasswordTxt.BackColor = System.Drawing.Color.White;
            this.AdminPasswordTxt.Location = new System.Drawing.Point(93, 189);
            this.AdminPasswordTxt.Name = "AdminPasswordTxt";
            this.AdminPasswordTxt.Size = new System.Drawing.Size(149, 20);
            this.AdminPasswordTxt.TabIndex = 13;
            this.toolTip1.SetToolTip(this.AdminPasswordTxt, "enter admin password\r\n");
            // 
            // AdminPasswordLbl
            // 
            this.AdminPasswordLbl.AutoSize = true;
            this.AdminPasswordLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminPasswordLbl.Location = new System.Drawing.Point(10, 189);
            this.AdminPasswordLbl.Name = "AdminPasswordLbl";
            this.AdminPasswordLbl.Size = new System.Drawing.Size(68, 16);
            this.AdminPasswordLbl.TabIndex = 12;
            this.AdminPasswordLbl.Text = "Password";
            // 
            // AdminNameTxt
            // 
            this.AdminNameTxt.BackColor = System.Drawing.Color.White;
            this.AdminNameTxt.Location = new System.Drawing.Point(93, 153);
            this.AdminNameTxt.Name = "AdminNameTxt";
            this.AdminNameTxt.Size = new System.Drawing.Size(149, 20);
            this.AdminNameTxt.TabIndex = 11;
            this.toolTip1.SetToolTip(this.AdminNameTxt, "enter admin name");
            // 
            // AdminNameLbl
            // 
            this.AdminNameLbl.AutoSize = true;
            this.AdminNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminNameLbl.Location = new System.Drawing.Point(10, 153);
            this.AdminNameLbl.Name = "AdminNameLbl";
            this.AdminNameLbl.Size = new System.Drawing.Size(45, 16);
            this.AdminNameLbl.TabIndex = 11;
            this.AdminNameLbl.Text = "Name";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.White;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Name",
            "Password"});
            this.comboBox1.Location = new System.Drawing.Point(93, 41);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(149, 21);
            this.comboBox1.TabIndex = 1;
            this.toolTip1.SetToolTip(this.comboBox1, "select edit field\r\nname,password");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Select Field";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel4.Controls.Add(this.editCloseBtn);
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Location = new System.Drawing.Point(977, 18);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(301, 285);
            this.panel4.TabIndex = 3;
            // 
            // editCloseBtn
            // 
            this.editCloseBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.editCloseBtn.Location = new System.Drawing.Point(120, 249);
            this.editCloseBtn.Name = "editCloseBtn";
            this.editCloseBtn.Size = new System.Drawing.Size(75, 23);
            this.editCloseBtn.TabIndex = 1;
            this.editCloseBtn.Text = "Close";
            this.toolTip1.SetToolTip(this.editCloseBtn, "close view");
            this.editCloseBtn.UseVisualStyleBackColor = false;
            this.editCloseBtn.Click += new System.EventHandler(this.editCloseBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(295, 240);
            this.dataGridView1.TabIndex = 0;
            // 
            // EditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(1290, 330);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "EditForm";
            this.Text = "EditForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.EditForm_FormClosed);
            this.Load += new System.EventHandler(this.EditForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Backbtn;
        private System.Windows.Forms.Button Selectbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Selectlbl;
        private System.Windows.Forms.ComboBox Fieldoption;
        private System.Windows.Forms.Button Backbtn1;
        private System.Windows.Forms.Button Updatebtn;
        private System.Windows.Forms.Label idlbl;
        private System.Windows.Forms.TextBox Updatetxt;
        private System.Windows.Forms.Label Newlbl;
        private System.Windows.Forms.TextBox Idtxt;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button AdminBackBtn;
        private System.Windows.Forms.TextBox AdminPasswordTxt;
        private System.Windows.Forms.Label AdminPasswordLbl;
        private System.Windows.Forms.TextBox AdminNameTxt;
        private System.Windows.Forms.Label AdminNameLbl;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox AdminIdTxt;
        private System.Windows.Forms.Label AdminIdLbl;
        private System.Windows.Forms.Button AdminUpdateBtn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button editCloseBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}