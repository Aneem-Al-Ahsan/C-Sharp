﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace PresentationLayer
{
    public partial class SearchAll : Form
    {
        public SearchAll()
        {
            InitializeComponent();
        }

        private void SearchAll_Load(object sender, EventArgs e)
        {

        }

        private void SearchAll_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            //StartForm startForm = new StartForm();
            //startForm.Show();
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "")
            {
                MessageBox.Show("Must select a search catagory");
            }
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.Text == "Hospital")
            {
                List<Hospital> hospitalList = new List<Hospital>();
                HospitalService hospitalService = new HospitalService();
                hospitalList = hospitalService.GetAll();
                dataGridView1.DataSource = hospitalList;
            }
            else if (listBox1.Text == "Pharmacy")
            {
                List<Pharmacy> pharmacyList = new List<Pharmacy>();
                PharmacyService pharmacyService = new PharmacyService();
                pharmacyList = pharmacyService.GetAll();
                dataGridView1.DataSource = pharmacyList;
            }
            else if (listBox1.Text == "Shopping Mall")
            {
                List<ShoppingMall> shoppingMallList = new List<ShoppingMall>();
                ShoppingMallService shoppingMallService = new ShoppingMallService();
                shoppingMallList = shoppingMallService.GetAll();
                dataGridView1.DataSource = shoppingMallList;
            }
            else if (listBox1.Text == "Resturaunt")
            {
                List<Restaurant> restaurantList = new List<Restaurant>();
                RestaurantService restaurantService = new RestaurantService();
                restaurantList = restaurantService.GetAll();
                dataGridView1.DataSource = restaurantList;
            }
            else
            {
                List<Admin> adminList = new List<Admin>();
                AdminService adminService = new AdminService();
                adminList = adminService.GetAll();
                dataGridView1.DataSource = adminList;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            googleMapName.Text= dataGridView1["Name", e.RowIndex].Value.ToString();
            googleMapArea.Text= dataGridView1["Area", e.RowIndex].Value.ToString();
        }

        private void googleMapBtn_Click(object sender, EventArgs e)
        {
            string name = googleMapName.Text;
            string area = googleMapArea.Text;
            StringBuilder queryAddress = new StringBuilder();
            queryAddress.Append("https://www.google.com/maps?q=");
            if (name != string.Empty)
            {
                queryAddress.Append(name+","+"+");
            }
            if (area != string.Empty)
            {
                queryAddress.Append(area + "," + "+");
            }
            webBrowser1.Navigate(queryAddress.ToString());

        }
    }
}
