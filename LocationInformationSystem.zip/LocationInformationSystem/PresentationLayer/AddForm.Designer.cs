﻿namespace PresentationLayer
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Catagorybackbtn = new System.Windows.Forms.Button();
            this.Addcatagorylbl = new System.Windows.Forms.Label();
            this.ListBox1 = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Startinginformationlbl = new System.Windows.Forms.Label();
            this.Areatxt = new System.Windows.Forms.TextBox();
            this.Phonetxt = new System.Windows.Forms.TextBox();
            this.Addresstxt = new System.Windows.Forms.TextBox();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.Idtxt = new System.Windows.Forms.TextBox();
            this.Arealbl = new System.Windows.Forms.Label();
            this.Phonelbl = new System.Windows.Forms.Label();
            this.Addresslbl = new System.Windows.Forms.Label();
            this.Namelbl = new System.Windows.Forms.Label();
            this.Idlbl = new System.Windows.Forms.Label();
            this.Informationbackbtn = new System.Windows.Forms.Button();
            this.Informationselectbtn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.AdminIdtxt = new System.Windows.Forms.TextBox();
            this.AdminIdlbl = new System.Windows.Forms.Label();
            this.Adminstartlbl = new System.Windows.Forms.Label();
            this.Adminbackbtn = new System.Windows.Forms.Button();
            this.Adminaddbtn = new System.Windows.Forms.Button();
            this.Confirmpasswordtxt = new System.Windows.Forms.TextBox();
            this.Confirmpasswordlbl = new System.Windows.Forms.Label();
            this.Adminpasswordtxt = new System.Windows.Forms.TextBox();
            this.Passwordlbl = new System.Windows.Forms.Label();
            this.Adminnametxt = new System.Windows.Forms.TextBox();
            this.Adminnamelbl = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.addGridViewBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel1.Controls.Add(this.Catagorybackbtn);
            this.panel1.Controls.Add(this.Addcatagorylbl);
            this.panel1.Controls.Add(this.ListBox1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(324, 324);
            this.panel1.TabIndex = 3;
            // 
            // Catagorybackbtn
            // 
            this.Catagorybackbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Catagorybackbtn.Location = new System.Drawing.Point(246, 298);
            this.Catagorybackbtn.Name = "Catagorybackbtn";
            this.Catagorybackbtn.Size = new System.Drawing.Size(75, 23);
            this.Catagorybackbtn.TabIndex = 5;
            this.Catagorybackbtn.Text = "Back";
            this.Catagorybackbtn.UseVisualStyleBackColor = false;
            this.Catagorybackbtn.Click += new System.EventHandler(this.Catagorybackbtn_Click);
            // 
            // Addcatagorylbl
            // 
            this.Addcatagorylbl.AutoSize = true;
            this.Addcatagorylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addcatagorylbl.Location = new System.Drawing.Point(99, 29);
            this.Addcatagorylbl.Name = "Addcatagorylbl";
            this.Addcatagorylbl.Size = new System.Drawing.Size(113, 16);
            this.Addcatagorylbl.TabIndex = 3;
            this.Addcatagorylbl.Text = "Choose Catagory";
            // 
            // ListBox1
            // 
            this.ListBox1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ListBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListBox1.FormattingEnabled = true;
            this.ListBox1.ItemHeight = 16;
            this.ListBox1.Items.AddRange(new object[] {
            "hospital",
            "pharmacy",
            "shoppingmall",
            "resturaunt",
            "admin"});
            this.ListBox1.Location = new System.Drawing.Point(102, 72);
            this.ListBox1.Name = "ListBox1";
            this.ListBox1.Size = new System.Drawing.Size(123, 148);
            this.ListBox1.TabIndex = 2;
            this.toolTip1.SetToolTip(this.ListBox1, "select location catagory\r\nhospital, pharmacy etc");
            this.ListBox1.SelectedIndexChanged += new System.EventHandler(this.ListBox1_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel2.Controls.Add(this.Startinginformationlbl);
            this.panel2.Controls.Add(this.Areatxt);
            this.panel2.Controls.Add(this.Phonetxt);
            this.panel2.Controls.Add(this.Addresstxt);
            this.panel2.Controls.Add(this.Nametxt);
            this.panel2.Controls.Add(this.Idtxt);
            this.panel2.Controls.Add(this.Arealbl);
            this.panel2.Controls.Add(this.Phonelbl);
            this.panel2.Controls.Add(this.Addresslbl);
            this.panel2.Controls.Add(this.Namelbl);
            this.panel2.Controls.Add(this.Idlbl);
            this.panel2.Controls.Add(this.Informationbackbtn);
            this.panel2.Controls.Add(this.Informationselectbtn);
            this.panel2.Location = new System.Drawing.Point(339, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(324, 366);
            this.panel2.TabIndex = 6;
            // 
            // Startinginformationlbl
            // 
            this.Startinginformationlbl.AutoSize = true;
            this.Startinginformationlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Startinginformationlbl.Location = new System.Drawing.Point(62, 0);
            this.Startinginformationlbl.Name = "Startinginformationlbl";
            this.Startinginformationlbl.Size = new System.Drawing.Size(127, 16);
            this.Startinginformationlbl.TabIndex = 16;
            this.Startinginformationlbl.Text = "Location Information";
            // 
            // Areatxt
            // 
            this.Areatxt.BackColor = System.Drawing.Color.White;
            this.Areatxt.Location = new System.Drawing.Point(65, 252);
            this.Areatxt.Name = "Areatxt";
            this.Areatxt.Size = new System.Drawing.Size(233, 20);
            this.Areatxt.TabIndex = 15;
            this.toolTip1.SetToolTip(this.Areatxt, "enter the area of\r\nthe location\r\n");
            // 
            // Phonetxt
            // 
            this.Phonetxt.BackColor = System.Drawing.Color.White;
            this.Phonetxt.Location = new System.Drawing.Point(65, 196);
            this.Phonetxt.Name = "Phonetxt";
            this.Phonetxt.Size = new System.Drawing.Size(233, 20);
            this.Phonetxt.TabIndex = 14;
            this.toolTip1.SetToolTip(this.Phonetxt, "enter the phone of\r\nthe location\r\n");
            // 
            // Addresstxt
            // 
            this.Addresstxt.BackColor = System.Drawing.Color.White;
            this.Addresstxt.Location = new System.Drawing.Point(65, 144);
            this.Addresstxt.Name = "Addresstxt";
            this.Addresstxt.Size = new System.Drawing.Size(233, 20);
            this.Addresstxt.TabIndex = 13;
            this.toolTip1.SetToolTip(this.Addresstxt, "enter the address of\r\nthe location");
            // 
            // Nametxt
            // 
            this.Nametxt.BackColor = System.Drawing.Color.White;
            this.Nametxt.Location = new System.Drawing.Point(65, 88);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(233, 20);
            this.Nametxt.TabIndex = 12;
            this.toolTip1.SetToolTip(this.Nametxt, "enter the name \r\nof the location");
            // 
            // Idtxt
            // 
            this.Idtxt.BackColor = System.Drawing.Color.White;
            this.Idtxt.Location = new System.Drawing.Point(65, 29);
            this.Idtxt.Name = "Idtxt";
            this.Idtxt.Size = new System.Drawing.Size(233, 20);
            this.Idtxt.TabIndex = 11;
            this.toolTip1.SetToolTip(this.Idtxt, "enter an ID for\r\nthe new location\r\n");
            // 
            // Arealbl
            // 
            this.Arealbl.AutoSize = true;
            this.Arealbl.Location = new System.Drawing.Point(3, 252);
            this.Arealbl.Name = "Arealbl";
            this.Arealbl.Size = new System.Drawing.Size(29, 13);
            this.Arealbl.TabIndex = 10;
            this.Arealbl.Text = "Area";
            // 
            // Phonelbl
            // 
            this.Phonelbl.AutoSize = true;
            this.Phonelbl.Location = new System.Drawing.Point(3, 196);
            this.Phonelbl.Name = "Phonelbl";
            this.Phonelbl.Size = new System.Drawing.Size(38, 13);
            this.Phonelbl.TabIndex = 9;
            this.Phonelbl.Text = "Phone";
            // 
            // Addresslbl
            // 
            this.Addresslbl.AutoSize = true;
            this.Addresslbl.Location = new System.Drawing.Point(3, 144);
            this.Addresslbl.Name = "Addresslbl";
            this.Addresslbl.Size = new System.Drawing.Size(45, 13);
            this.Addresslbl.TabIndex = 8;
            this.Addresslbl.Text = "Address";
            // 
            // Namelbl
            // 
            this.Namelbl.AutoSize = true;
            this.Namelbl.Location = new System.Drawing.Point(3, 88);
            this.Namelbl.Name = "Namelbl";
            this.Namelbl.Size = new System.Drawing.Size(35, 13);
            this.Namelbl.TabIndex = 7;
            this.Namelbl.Text = "Name";
            // 
            // Idlbl
            // 
            this.Idlbl.AutoSize = true;
            this.Idlbl.Location = new System.Drawing.Point(3, 29);
            this.Idlbl.Name = "Idlbl";
            this.Idlbl.Size = new System.Drawing.Size(18, 13);
            this.Idlbl.TabIndex = 6;
            this.Idlbl.Text = "ID";
            // 
            // Informationbackbtn
            // 
            this.Informationbackbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Informationbackbtn.Location = new System.Drawing.Point(246, 298);
            this.Informationbackbtn.Name = "Informationbackbtn";
            this.Informationbackbtn.Size = new System.Drawing.Size(75, 23);
            this.Informationbackbtn.TabIndex = 5;
            this.Informationbackbtn.Text = "Back";
            this.Informationbackbtn.UseVisualStyleBackColor = false;
            this.Informationbackbtn.Click += new System.EventHandler(this.Informationbackbtn_Click);
            // 
            // Informationselectbtn
            // 
            this.Informationselectbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Informationselectbtn.Location = new System.Drawing.Point(3, 298);
            this.Informationselectbtn.Name = "Informationselectbtn";
            this.Informationselectbtn.Size = new System.Drawing.Size(75, 23);
            this.Informationselectbtn.TabIndex = 4;
            this.Informationselectbtn.Text = "Add";
            this.Informationselectbtn.UseVisualStyleBackColor = false;
            this.Informationselectbtn.Click += new System.EventHandler(this.Informationselectbtn_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel3.Controls.Add(this.AdminIdtxt);
            this.panel3.Controls.Add(this.AdminIdlbl);
            this.panel3.Controls.Add(this.Adminstartlbl);
            this.panel3.Controls.Add(this.Adminbackbtn);
            this.panel3.Controls.Add(this.Adminaddbtn);
            this.panel3.Controls.Add(this.Confirmpasswordtxt);
            this.panel3.Controls.Add(this.Confirmpasswordlbl);
            this.panel3.Controls.Add(this.Adminpasswordtxt);
            this.panel3.Controls.Add(this.Passwordlbl);
            this.panel3.Controls.Add(this.Adminnametxt);
            this.panel3.Controls.Add(this.Adminnamelbl);
            this.panel3.Location = new System.Drawing.Point(669, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(272, 365);
            this.panel3.TabIndex = 7;
            // 
            // AdminIdtxt
            // 
            this.AdminIdtxt.BackColor = System.Drawing.Color.White;
            this.AdminIdtxt.Location = new System.Drawing.Point(7, 71);
            this.AdminIdtxt.Name = "AdminIdtxt";
            this.AdminIdtxt.Size = new System.Drawing.Size(212, 20);
            this.AdminIdtxt.TabIndex = 26;
            this.toolTip1.SetToolTip(this.AdminIdtxt, "enter an ID\r\nfor the new admin");
            // 
            // AdminIdlbl
            // 
            this.AdminIdlbl.AutoSize = true;
            this.AdminIdlbl.Location = new System.Drawing.Point(4, 55);
            this.AdminIdlbl.Name = "AdminIdlbl";
            this.AdminIdlbl.Size = new System.Drawing.Size(18, 13);
            this.AdminIdlbl.TabIndex = 25;
            this.AdminIdlbl.Text = "ID";
            // 
            // Adminstartlbl
            // 
            this.Adminstartlbl.AutoSize = true;
            this.Adminstartlbl.Location = new System.Drawing.Point(80, 9);
            this.Adminstartlbl.Name = "Adminstartlbl";
            this.Adminstartlbl.Size = new System.Drawing.Size(91, 13);
            this.Adminstartlbl.TabIndex = 24;
            this.Adminstartlbl.Text = "Admin Information";
            // 
            // Adminbackbtn
            // 
            this.Adminbackbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Adminbackbtn.Location = new System.Drawing.Point(183, 298);
            this.Adminbackbtn.Name = "Adminbackbtn";
            this.Adminbackbtn.Size = new System.Drawing.Size(75, 23);
            this.Adminbackbtn.TabIndex = 17;
            this.Adminbackbtn.Text = "Back";
            this.Adminbackbtn.UseVisualStyleBackColor = false;
            this.Adminbackbtn.Click += new System.EventHandler(this.Adminbackbtn_Click);
            // 
            // Adminaddbtn
            // 
            this.Adminaddbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.Adminaddbtn.Location = new System.Drawing.Point(0, 298);
            this.Adminaddbtn.Name = "Adminaddbtn";
            this.Adminaddbtn.Size = new System.Drawing.Size(75, 23);
            this.Adminaddbtn.TabIndex = 17;
            this.Adminaddbtn.Text = "Add";
            this.Adminaddbtn.UseVisualStyleBackColor = false;
            this.Adminaddbtn.Click += new System.EventHandler(this.Adminaddbtn_Click);
            // 
            // Confirmpasswordtxt
            // 
            this.Confirmpasswordtxt.BackColor = System.Drawing.Color.White;
            this.Confirmpasswordtxt.Location = new System.Drawing.Point(6, 195);
            this.Confirmpasswordtxt.Name = "Confirmpasswordtxt";
            this.Confirmpasswordtxt.Size = new System.Drawing.Size(212, 20);
            this.Confirmpasswordtxt.TabIndex = 23;
            this.toolTip1.SetToolTip(this.Confirmpasswordtxt, "re-enter password\r\nfor confiramtion");
            // 
            // Confirmpasswordlbl
            // 
            this.Confirmpasswordlbl.AutoSize = true;
            this.Confirmpasswordlbl.Location = new System.Drawing.Point(4, 179);
            this.Confirmpasswordlbl.Name = "Confirmpasswordlbl";
            this.Confirmpasswordlbl.Size = new System.Drawing.Size(91, 13);
            this.Confirmpasswordlbl.TabIndex = 22;
            this.Confirmpasswordlbl.Text = "Confirm Password";
            // 
            // Adminpasswordtxt
            // 
            this.Adminpasswordtxt.BackColor = System.Drawing.Color.White;
            this.Adminpasswordtxt.Location = new System.Drawing.Point(6, 156);
            this.Adminpasswordtxt.Name = "Adminpasswordtxt";
            this.Adminpasswordtxt.Size = new System.Drawing.Size(212, 20);
            this.Adminpasswordtxt.TabIndex = 21;
            this.toolTip1.SetToolTip(this.Adminpasswordtxt, "enter password of\r\nadmin");
            this.Adminpasswordtxt.TextChanged += new System.EventHandler(this.Adminpasswordtxt_TextChanged);
            // 
            // Passwordlbl
            // 
            this.Passwordlbl.AutoSize = true;
            this.Passwordlbl.Location = new System.Drawing.Point(4, 140);
            this.Passwordlbl.Name = "Passwordlbl";
            this.Passwordlbl.Size = new System.Drawing.Size(53, 13);
            this.Passwordlbl.TabIndex = 20;
            this.Passwordlbl.Text = "Password";
            this.Passwordlbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // Adminnametxt
            // 
            this.Adminnametxt.BackColor = System.Drawing.Color.White;
            this.Adminnametxt.Location = new System.Drawing.Point(7, 117);
            this.Adminnametxt.Name = "Adminnametxt";
            this.Adminnametxt.Size = new System.Drawing.Size(212, 20);
            this.Adminnametxt.TabIndex = 19;
            this.toolTip1.SetToolTip(this.Adminnametxt, "enter a name\r\nfor the new admin\r\n");
            this.Adminnametxt.TextChanged += new System.EventHandler(this.Adminnametxt_TextChanged);
            // 
            // Adminnamelbl
            // 
            this.Adminnamelbl.AutoSize = true;
            this.Adminnamelbl.Location = new System.Drawing.Point(4, 94);
            this.Adminnamelbl.Name = "Adminnamelbl";
            this.Adminnamelbl.Size = new System.Drawing.Size(35, 13);
            this.Adminnamelbl.TabIndex = 18;
            this.Adminnamelbl.Text = "Name";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel4.Controls.Add(this.addGridViewBtn);
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Location = new System.Drawing.Point(947, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(291, 342);
            this.panel4.TabIndex = 8;
            // 
            // addGridViewBtn
            // 
            this.addGridViewBtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.addGridViewBtn.Location = new System.Drawing.Point(115, 316);
            this.addGridViewBtn.Name = "addGridViewBtn";
            this.addGridViewBtn.Size = new System.Drawing.Size(75, 23);
            this.addGridViewBtn.TabIndex = 1;
            this.addGridViewBtn.Text = "Close";
            this.addGridViewBtn.UseVisualStyleBackColor = false;
            this.addGridViewBtn.Click += new System.EventHandler(this.addGridViewBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(4, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(285, 306);
            this.dataGridView1.TabIndex = 0;
            // 
            // AddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1298, 406);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "AddForm";
            this.Text = "AddForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddForm_FormClosed);
            this.Load += new System.EventHandler(this.AddForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Addcatagorylbl;
        private System.Windows.Forms.ListBox ListBox1;
        private System.Windows.Forms.Button Catagorybackbtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Startinginformationlbl;
        private System.Windows.Forms.TextBox Areatxt;
        private System.Windows.Forms.TextBox Phonetxt;
        private System.Windows.Forms.TextBox Addresstxt;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox Idtxt;
        private System.Windows.Forms.Label Arealbl;
        private System.Windows.Forms.Label Phonelbl;
        private System.Windows.Forms.Label Addresslbl;
        private System.Windows.Forms.Label Namelbl;
        private System.Windows.Forms.Label Idlbl;
        private System.Windows.Forms.Button Informationbackbtn;
        private System.Windows.Forms.Button Informationselectbtn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label Passwordlbl;
        private System.Windows.Forms.TextBox Adminnametxt;
        private System.Windows.Forms.Label Adminnamelbl;
        private System.Windows.Forms.TextBox Adminpasswordtxt;
        private System.Windows.Forms.Label Adminstartlbl;
        private System.Windows.Forms.Button Adminbackbtn;
        private System.Windows.Forms.Button Adminaddbtn;
        private System.Windows.Forms.TextBox Confirmpasswordtxt;
        private System.Windows.Forms.Label Confirmpasswordlbl;
        private System.Windows.Forms.TextBox AdminIdtxt;
        private System.Windows.Forms.Label AdminIdlbl;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button addGridViewBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}