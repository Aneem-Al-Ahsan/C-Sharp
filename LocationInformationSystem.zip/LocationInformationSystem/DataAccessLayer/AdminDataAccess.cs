﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using EntityLayer;
using BusinessAccessLayer;
using System.Windows.Forms;


namespace DataAccessLayer
{
    public class AdminDataAccess
    {
        public int Add(Admin admin)
        {
            string query = string.Format("INSERT INTO Admin1 VALUES({0}, '{1}','{2}')",admin.Id,admin.Name,admin.Password);
            return DataAccess.ExecuteQuery(query);
        }
        public int EditName(Admin admin)
        {
            string query = "Update Admin1 set Name = '" + admin.Name + "' where Id = " + (admin.Id).ToString();
            return DataAccess.ExecuteQuery(query);
        }
        public int EditPassword(Admin admin)
        {
            string query = "Update Admin1 set Password = '" + admin.Password + "' where Id = " + (admin.Id).ToString();
            return DataAccess.ExecuteQuery(query);
        }
        public int Delete(Admin admin)
        {
            string query = string.Format("Delete from Admin1 where id=" + admin.Id);
            return DataAccess.ExecuteQuery(query);
        }
        public List<Admin> GetAll()
        {
            string query = "SELECT * FROM Admin1";
            SqlDataReader reader = DataAccess.GetData(query);

            Admin admin = null;
            List<Admin> adminList = new List<Admin>();
            while (reader.Read())
            {
                admin = new Admin();
                admin.Id = Convert.ToInt32(reader["Id"]);
                admin.Name = reader["Name"].ToString();
                admin.Password = reader["Password"].ToString();
                

                adminList.Add(admin);
            }
            return adminList;
        }
    }
}
